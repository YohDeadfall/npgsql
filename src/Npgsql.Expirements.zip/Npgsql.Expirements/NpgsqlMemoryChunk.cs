﻿using System;

namespace Npgsql.Expirements
{
    internal sealed class NpgsqlMemoryChunk
    {
        public NpgsqlMemoryChunk? Next;
        private readonly byte[] _buffer;

        public NpgsqlMemoryChunk() => _buffer = new byte[Environment.SystemPageSize];

        public Span<byte> Unused => new Span<byte>(_buffer, UsedLength, UnusedLength);
        public Memory<byte> UnusedMemory => new Memory<byte>(_buffer, UsedLength, UnusedLength);
        public int UnusedLength => _buffer.Length - UsedLength;

        public Span<byte> Used => new Span<byte>(_buffer, 0, UsedLength);
        public Memory<byte> UsedMemory => new Memory<byte>(_buffer, 0, UsedLength);
        public int UsedLength { get; private set; }

        public void Advance(int size) => UsedLength += size;

        public void Seek(int position) => UsedLength = position;
    }
}
