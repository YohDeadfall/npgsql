﻿using Npgsql.Expirements.TypeHandling;
using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace Npgsql.Expirements
{
    public sealed class NpgsqlDataReader
    {
        private int _previousOrdinal;
        private Type? _previousReturnType;
        private NpgsqlTypeHandler? _previousHandler;

        public ValueTask<T> GetFieldValueAsync<T>(int ordinal)
        {
            if (ReferenceEquals(GetFieldValueCall<T>.ReturnType, _previousReturnType))
            {
                Debug.Assert(_previousHandler != null);

                var handler = Unsafe.As<NpgsqlTypeHandler<T>>(_previousHandler);
                return handler.ReadAsync(null!);
            }

            throw new NotImplementedException("Go slow");
        }

        private static class GetFieldValueCall<T>
        {
            public static readonly Type ReturnType = typeof(T);
        }
    }
}
