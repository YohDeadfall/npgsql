﻿using Npgsql.Expirements.TypeHandling;
using System;
using System.Buffers.Binary;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace Npgsql.Expirements
{
    public sealed class NpgsqlStreamReader
    {
        private readonly Stream _stream;
        private NpgsqlMemoryChunk _head;
        private NpgsqlMemoryChunk _tail;

        public NpgsqlStreamReader(Stream stream)
        {
            _stream = stream;
            _head = _tail = new NpgsqlMemoryChunk();
            _head.Advance(_head.UnusedLength);
        }

        public ReadOnlySpan<byte> GetSpan(int size) => throw new NotImplementedException();

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public byte ReadByte() => Read<byte>();

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public short ReadInt16(bool littleEndian = false)
        {
            var value = Read<short>();
            return littleEndian == BitConverter.IsLittleEndian
                ? value : BinaryPrimitives.ReverseEndianness(value);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public int ReadInt32(bool littleEndian = false)
        {
            var value = Read<int>();
            return littleEndian == BitConverter.IsLittleEndian
                ? value : BinaryPrimitives.ReverseEndianness(value);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public long ReadInt64(bool littleEndian = false)
        {
            var value = Read<long>();
            return littleEndian == BitConverter.IsLittleEndian
                ? value : BinaryPrimitives.ReverseEndianness(value);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private T Read<T>()
            where T : unmanaged
        {
            var requiredSize = Unsafe.SizeOf<T>();
            if (requiredSize > _head.UnusedLength)
                return ReadSlow<T>();

            var unused = _head.Unused;
            var result = MemoryMarshal.Read<T>(unused);

            _head.Advance(Unsafe.SizeOf<T>());

            return result;
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        private T ReadSlow<T>()
            where T : unmanaged
        {
            var value = default(T);
            var bytes = MemoryMarshal.AsBytes(
                MemoryMarshal.CreateSpan(ref value, 1));

            var unread = Unsafe.SizeOf<T>();
            while (unread > 0)
            {
                if (_head.UnusedLength == 0)
                    _head = _head.Next ?? throw new InvalidOperationException();

                var available = Math.Min(_head.UnusedLength, unread);
                var destination = bytes[..unread];

                _head.Unused[available..].CopyTo(destination);
                _head.Advance(available);

                unread -= available;
            }

            return value;
        }

        public ValueTask Ensure(int requiredSize) => throw new NotImplementedException();

        internal ValueTask<T> ReadAsync<T>(NpgsqlTypeHandler<T> handler)
        {
            if (sizeof(int) + handler.Length <= _head.UnusedLength)
            {
                var length = ReadInt32();
                return handler.ReadValueAsync(this, length);
            }

            return ReadAsyncCore();

            async ValueTask<T> ReadAsyncCore()
            {
                _head.Next = new NpgsqlMemoryChunk();
                _head.Unused.CopyTo(_head.Next.Unused);
                _head = _head.Next;

                await _stream.ReadAsync(_head.UnusedMemory.Slice(sizeof(int)));

                var length = ReadInt32();
                return await handler.ReadValueAsync(this, length);
            }
        }
    }
}
