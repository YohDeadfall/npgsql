﻿namespace Npgsql.Expirements
{
    public class NpgsqlParameter
    {
        public virtual object? Value { get; set; }
    }
}
