﻿using Npgsql.Expirements.TypeHandling;
using System;
using System.Buffers.Binary;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace Npgsql.Expirements
{
    public sealed class NpgsqlStreamWriter
    {
        private readonly Stream _underlyingStream;
        private NpgsqlMemoryChunk _head;
        private NpgsqlMemoryChunk _tail;
        private int _length;

        public NpgsqlStreamWriter(Stream underlyingStream)
        {
            _underlyingStream = underlyingStream;
            _head = _tail = new NpgsqlMemoryChunk();
        }

        public Span<byte> GetSpan() => _tail.Unused;

        public Span<byte> GetSpan(int size) => _tail.Unused;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void WriteByte(byte value) => Write(value);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void WriteInt16(short value, bool littleEndian = false) =>
            Write(littleEndian == BitConverter.IsLittleEndian ? value : BinaryPrimitives.ReverseEndianness(value));

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void WriteInt32(int value, bool littleEndian = false) =>
            Write(littleEndian == BitConverter.IsLittleEndian ? value : BinaryPrimitives.ReverseEndianness(value));

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void WriteInt64(long value, bool littleEndian = false) =>
            Write(littleEndian == BitConverter.IsLittleEndian ? value : BinaryPrimitives.ReverseEndianness(value));

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private void Write<T>(T value)
            where T : unmanaged
        {
            EnsureWriteSpace(Unsafe.SizeOf<T>());
            MemoryMarshal.Write(_tail.Unused, ref value);

            _tail.Advance(Unsafe.SizeOf<T>());
            _length += Unsafe.SizeOf<T>();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private void EnsureWriteSpace(int requiredSize)
        {
            if (requiredSize > _tail.UnusedLength)
                Allocate();

            void Allocate()
            {
                _tail.Next = new NpgsqlMemoryChunk();
                _tail = _tail.Next;
            }
        }

        private void Write<T>(NpgsqlTypeHandler<T> handler, T value)
        {
            if (value is null || value is DBNull)
                WriteInt32(-1);
            else
            {
                EnsureWriteSpace(sizeof(int));

                var length = _length += sizeof(int);
                var lengthSpace = _tail.Unused;

                _tail.Advance(sizeof(int));

                handler.WriteValue(this, value);
                BinaryPrimitives.WriteInt32BigEndian(lengthSpace, _length - length);
            }
        }

        internal async ValueTask FlushAsync()
        {
            for (var chunk = _head; chunk != null; chunk = chunk.Next)
                await _underlyingStream.WriteAsync(chunk.UsedMemory, default);
        }
    }
}
