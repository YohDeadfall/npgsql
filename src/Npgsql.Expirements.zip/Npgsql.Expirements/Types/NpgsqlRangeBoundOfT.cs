﻿using System;

namespace Npgsql.Expirements
{
    public readonly struct NpgsqlRangeBound<T> : IEquatable<NpgsqlRangeBound<T>>
        where T : IEquatable<T>, IComparable<T>
    {
        private readonly T _value;
        private readonly Flags _flags;

        public NpgsqlRangeBound(T value);
        public NpgsqlRangeBound(T value, bool isInclusive);

        public bool IsInclusive => _flags.HasFlag(Flags.Inclusive);
        public bool IsInfinite => _flags.HasFlag(Flags.Infinity);
        public T Value => _value;

        public int CompareTo(NpgsqlRangeBound<T> other);
        public bool Equals(NpgsqlRangeBound<T> other);
        public override bool Equals(object? other) => other is NpgsqlRangeBound<T> bound && Equals(bound);
        public override int GetHashCode() => HashCode.Combine(_value, _flags);

        public static bool operator ==(NpgsqlRangeBound<T> left, NpgsqlRangeBound<T> right);
        public static bool operator !=(NpgsqlRangeBound<T> left, NpgsqlRangeBound<T> right);

        public static bool operator <(NpgsqlRangeBound<T> left, NpgsqlRangeBound<T> right);
        public static bool operator <=(NpgsqlRangeBound<T> left, NpgsqlRangeBound<T> right);

        public static bool operator >(NpgsqlRangeBound<T> left, NpgsqlRangeBound<T> right);
        public static bool operator >=(NpgsqlRangeBound<T> left, NpgsqlRangeBound<T> right);

        public static implicit operator NpgsqlRangeBound<T>(T value) => new NpgsqlRangeBound<T>(value);

        [Flags]
        private enum Flags
        {
            Inclusive = 1,
            Infinity = 2
        }
    }
}
