﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Npgsql.Expirements
{
    public static class NpgsqlRange
    {
        public static NpgsqlRange<T> Empty<T>()
            where T : IEquatable<T>, IComparable<T> =>
            default;
    }
    public readonly struct NpgsqlRange<T> : IEquatable<NpgsqlRange<T>>
        where T : IEquatable<T>, IComparable<T>
    {
        internal NpgsqlRangeFlags Flags { get; }
        internal T LowerBoundValue { get; }
        internal T UpperBoundValue { get; }


        public NpgsqlRange(NpgsqlRangeBound<T> lowerBound, NpgsqlRangeBound<T> upperBound) =>
            (LowerBound, UpperBound) = (lowerBound, upperBound);

        internal NpgsqlRange([AllowNull] T lowerBound, [AllowNull] T upperBound, NpgsqlRangeFlags flags);

        public NpgsqlRangeBound<T> LowerBound { get; }
        public NpgsqlRangeBound<T> UpperBound { get; }

        public bool IsEmpty => LowerBound == UpperBound;

        public bool Equals(NpgsqlRange<T> other)
        {
            throw new NotImplementedException();
        }
    }

    [Flags]
    internal enum NpgsqlRangeFlags : byte
    {
        None = 0,
        Empty = 1,
        LowerBoundInclusive = 2,
        UpperBoundInclusive = 4,
        LowerBoundInfinite = 8,
        UpperBoundInfinite = 16,
    }
}
