﻿using System;

namespace Npgsql.Expirements.Types
{
    public readonly struct NpgsqlTimestamp : IEquatable<NpgsqlTimestamp>, IComparable<NpgsqlTimestamp>
    {
        private readonly long _value;

        private const long DaysSinceEra = 730119;  // 730119 = days since era (0001-01-01) for 2000-01-01
        private const long TicksPerDay = 86400000000L;

        public bool IsInfinity { get; }
        public bool IsNegative => _value < 0;

        public NpgsqlTimestamp(long value) => _value = value;

        public NpgsqlTimestamp(DateTime value)
        {
            var ticks = value.Ticks;
            var date = Math.DivRem(ticks, TimeSpan.TicksPerDay, out var time);

            date -= DaysSinceEra;
            time /= 10;

            _value = date * TicksPerDay + time;
        }

        public DateTime ToDateTime()
        {
            var native = ToNativeValue();
            var date = Math.DivRem(native, TicksPerDay, out var time);

            if (native < 0 & time != 0)
            {
                date -= 1;
                time = TicksPerDay + time;
            }

            date += DaysSinceEra;
            time *= 10; // To 100ns

            var ticks = Math.Abs(date * TimeSpan.TicksPerDay + time);
            return new DateTime(ticks);
        }

        public long ToNativeValue() => _value;

        public override string ToString() => ToDateTime().ToString();

        public int CompareTo(NpgsqlTimestamp other) =>
            this == other ? 0 : this < other ? -1 : 1; 

        public bool Equals(NpgsqlTimestamp other) =>
            this == other;

        public override bool Equals(object? obj) =>
            obj is NpgsqlTimestamp timestamp && Equals(timestamp);

        public override int GetHashCode() =>
            ToNativeValue().GetHashCode();

        public static bool operator ==(NpgsqlTimestamp left, NpgsqlTimestamp right) => left.ToNativeValue() == right.ToNativeValue();
        public static bool operator !=(NpgsqlTimestamp left, NpgsqlTimestamp right) => left.ToNativeValue() != right.ToNativeValue();

        public static bool operator <(NpgsqlTimestamp left, NpgsqlTimestamp right) => left.ToNativeValue() < right.ToNativeValue();
        public static bool operator <=(NpgsqlTimestamp left, NpgsqlTimestamp right) => left.ToNativeValue() <= right.ToNativeValue();

        public static bool operator >(NpgsqlTimestamp left, NpgsqlTimestamp right) => left.ToNativeValue() > right.ToNativeValue();
        public static bool operator >=(NpgsqlTimestamp left, NpgsqlTimestamp right) => left.ToNativeValue() >= right.ToNativeValue();
    }
}
