﻿using System;

namespace Npgsql.Expirements.Types
{
    public readonly struct NpgsqlTimestamptz : IEquatable<NpgsqlTimestamptz>
    {
        private readonly NpgsqlTimestamp _value;

        public NpgsqlTimestamptz(long value) =>
            _value = new NpgsqlTimestamp(value);

        public NpgsqlTimestamptz(DateTimeOffset value) =>
            _value = new NpgsqlTimestamp(value.UtcDateTime);

        public long ToNativeValue() =>
            _value.ToNativeValue();

        public DateTimeOffset ToDateTimeOffset() =>
            new DateTimeOffset(_value.ToDateTime().Ticks, TimeSpan.Zero);

        public override string ToString() =>
            ToDateTimeOffset().ToString();

        public int CompareTo(NpgsqlTimestamptz other) =>
            this == other ? 0 : this < other ? -1 : 1;

        public bool Equals(NpgsqlTimestamptz other) =>
            this == other;

        public override bool Equals(object? obj) =>
            obj is NpgsqlTimestamptz timestamp && Equals(timestamp);

        public override int GetHashCode() =>
            ToNativeValue().GetHashCode();

        public static bool operator ==(NpgsqlTimestamptz left, NpgsqlTimestamptz right) => left.ToNativeValue() == right.ToNativeValue();
        public static bool operator !=(NpgsqlTimestamptz left, NpgsqlTimestamptz right) => left.ToNativeValue() != right.ToNativeValue();

        public static bool operator <(NpgsqlTimestamptz left, NpgsqlTimestamptz right) => left.ToNativeValue() < right.ToNativeValue();
        public static bool operator <=(NpgsqlTimestamptz left, NpgsqlTimestamptz right) => left.ToNativeValue() <= right.ToNativeValue();

        public static bool operator >(NpgsqlTimestamptz left, NpgsqlTimestamptz right) => left.ToNativeValue() > right.ToNativeValue();
        public static bool operator >=(NpgsqlTimestamptz left, NpgsqlTimestamptz right) => left.ToNativeValue() >= right.ToNativeValue();
    }
}
