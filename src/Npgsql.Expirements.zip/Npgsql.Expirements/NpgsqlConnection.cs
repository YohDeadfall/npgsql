﻿using Npgsql.Expirements.TypeHandling;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Npgsql.Expirements
{
    public abstract class NpgsqlConnection
    {
        public abstract NpgsqlTypeMapper TypeMapper { get; }
    }

    public sealed class NpgsqlTypeMapper
    {
        public NpgsqlTypeHandler GetHandler(Type type) => throw new NotImplementedException();

        public NpgsqlTypeHandler GetHandler(PostgresType type) => throw new NotImplementedException();
    }
}
