﻿using System;
using System.Threading.Tasks;

namespace Npgsql.Expirements.TypeHandling
{
    public abstract class NpgsqlTypeHandler
    {
        internal NpgsqlTypeHandler()
        {
        }

        internal abstract ValueTask<object?> ReadObjectAsync(NpgsqlStreamReader stream);

        internal abstract void WriteParameter(NpgsqlStreamWriter stream, NpgsqlParameter parameter);

        internal abstract NpgsqlTypeHandler CreateHandler(Type runtimeType, PostgresType postgresType, NpgsqlTypeHandlerFactory factory);
    }
}
