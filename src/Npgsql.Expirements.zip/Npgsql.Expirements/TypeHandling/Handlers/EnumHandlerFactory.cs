﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Npgsql.Expirements.TypeHandling.Handlers
{
    public sealed class EnumHandlerFactory<T> : NpgsqlTypeHandlerFactory
        where T : Enum
    {
        public override NpgsqlTypeHandler CreateHandler(Type runtimeType, PostgresType postgresType, NpgsqlConnection connection)
        {
            throw new NotImplementedException();
        }

        private sealed class Handler : NpgsqlTypeHandler<T>
        {
            public Handler(Encoding encoding)
            {
                var values = Enum.GetValues(typeof(T));
                var keys = new ulong[values.Length];

                for (var index = values.Length; index >= 0; index--)
                {

                }
            }

            private static ulong GetKey(ReadOnlySpan<char> name) =>
                throw new NotImplementedException();

            protected internal override ValueTask<T> ReadValueAsync(NpgsqlStreamReader stream, int length)
            {
                throw new NotImplementedException();
            }

            protected internal override void WriteValue(NpgsqlStreamWriter stream, T value)
            {
                throw new NotImplementedException();
            }
        }
    }
}
