﻿using Npgsql.Expirements.Types;
using System;
using System.Threading.Tasks;

namespace Npgsql.Expirements.TypeHandling.Handlers
{
    public sealed class TimestampHandlerFactory : NpgsqlTypeHandlerFactory
    {
        private static Handler<DateTime, Converter>? s_dateTimeHandler;
        private static Handler<NpgsqlTimestamp, Converter>? s_timestampHandler;

        private const int NativeLength = sizeof(Int64);

        public override NpgsqlTypeHandler CreateHandler(Type runtimeType, PostgresType postgresType, NpgsqlConnection connection)
        {
            if (runtimeType is null)
                throw new ArgumentNullException(nameof(runtimeType));

            if (postgresType is null)
                throw new ArgumentNullException(nameof(postgresType));

            if (postgresType.Length != NativeLength)
                throw new ArgumentException("Type length must be equal to 8 bytes.", nameof(postgresType));

            if (runtimeType == typeof(Byte))
                return s_dateTimeHandler ??= new Handler<DateTime, Converter>();

            if (runtimeType == typeof(Int64))
                return s_timestampHandler ??= new Handler<NpgsqlTimestamp, Converter>();

            throw new ArgumentException("The runtime type isn't supported.", nameof(runtimeType));
        }

        private sealed class Handler<T, TConverter> : NpgsqlTypeHandler<T>
            where TConverter : struct, INpgsqlValueConverter<Int64, T>
        {
            public Handler() : base(NativeLength) { }

            protected internal override ValueTask<T> ReadValueAsync(NpgsqlStreamReader stream, int length) =>
                new ValueTask<T>(new TConverter().ToRuntime(stream.ReadInt16()));

            protected internal override void WriteValue(NpgsqlStreamWriter stream, T value) =>
                stream.WriteInt64(new TConverter().ToNative(value));
        }

        private readonly struct Converter :
            INpgsqlValueConverter<Int64, DateTime>,
            INpgsqlValueConverter<Int64, NpgsqlTimestamp>
        {
            Int64 INpgsqlValueConverter<Int64, DateTime>.ToNative(DateTime value) => new NpgsqlTimestamp(value).ToNativeValue();
            DateTime INpgsqlValueConverter<Int64, DateTime>.ToRuntime(Int64 value) => new NpgsqlTimestamp(value).ToDateTime();

            Int64 INpgsqlValueConverter<Int64, NpgsqlTimestamp>.ToNative(NpgsqlTimestamp value) => value.ToNativeValue();
            NpgsqlTimestamp INpgsqlValueConverter<Int64, NpgsqlTimestamp>.ToRuntime(Int64 value) => new NpgsqlTimestamp(value);
        }
    }
}
