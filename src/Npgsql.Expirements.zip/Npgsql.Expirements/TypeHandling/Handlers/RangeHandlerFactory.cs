﻿using System;
using System.Threading.Tasks;

namespace Npgsql.Expirements.TypeHandling.Handlers
{
    public sealed class RangeHandlerFactory<T> : NpgsqlTypeHandlerFactory
        where T : IEquatable<T>, IComparable<T>
    {
        public override NpgsqlTypeHandler CreateHandler(Type runtimeType, PostgresType postgresType, NpgsqlConnection connection)
        {
            if (runtimeType is null)
                throw new ArgumentNullException(nameof(runtimeType));

            return new Handler(connection.TypeMapper.GetHandler(runtimeType));
        }

        private sealed class Handler : NpgsqlTypeHandler<NpgsqlRange<T>>
        {
            public NpgsqlTypeHandler<T> ElementHandler { get; }

            public Handler(NpgsqlTypeHandler<T> elementHandler) => ElementHandler = elementHandler;

            protected internal override async ValueTask<NpgsqlRange<T>> ReadValueAsync(NpgsqlStreamReader stream, int length)
            {
                var flags = (NpgsqlRangeFlags)stream.ReadByte();
                if (flags == NpgsqlRangeFlags.Empty)
                    return default;

                var lowerBound = flags.HasFlag(NpgsqlRangeFlags.LowerBoundInfinite)
                    ? default
                    : await ElementHandler.ReadAsync(stream);

                var upperBound = flags.HasFlag(NpgsqlRangeFlags.UpperBoundInfinite)
                    ? default
                    : await ElementHandler.ReadAsync(stream);

                return new NpgsqlRange<T>(lowerBound, upperBound, flags);
            }

            protected internal override void WriteValue(NpgsqlStreamWriter stream, NpgsqlRange<T> value)
            {
                if (value.IsEmpty)
                    stream.WriteByte((byte)NpgsqlRangeFlags.Empty);
                else
                {
                    var flags = value.Flags;

                    stream.WriteByte((byte)flags);

                    if (!flags.HasFlag(NpgsqlRangeFlags.LowerBoundInfinite))
                        ElementHandler.Write(stream, value.LowerBoundValue);

                    if (!flags.HasFlag(NpgsqlRangeFlags.UpperBoundInfinite))
                        ElementHandler.Write(stream, value.UpperBoundValue);
                }
            }
        }
    }
}
