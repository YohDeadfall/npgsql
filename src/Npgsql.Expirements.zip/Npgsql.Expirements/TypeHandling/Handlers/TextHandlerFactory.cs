﻿using System;
using System.Text;
using System.Threading.Tasks;

namespace Npgsql.Expirements.TypeHandling.Handlers
{
    public sealed class TextHandlerFactory : NpgsqlTypeHandlerFactory
    {
        public override NpgsqlTypeHandler CreateHandler(Type runtimeType, PostgresType postgresType, NpgsqlConnection connection)
        {
            throw new NotImplementedException();
        }

        private abstract class Handler<T> : NpgsqlTypeHandler<T>
        {
            protected readonly Encoding Encoding;

            public Handler(Encoding encoding) => Encoding = encoding;
        }

        private sealed class CharHandler : Handler<char>
        {
            public CharHandler(Encoding encoding) : base(encoding) { }

            protected internal override ValueTask<char> ReadValueAsync(NpgsqlStreamReader stream, int length)
            {
                throw new NotImplementedException();
            }

            protected internal override void WriteValue(NpgsqlStreamWriter stream, char value)
            {
                throw new NotImplementedException();
            }
        }

        private sealed class StringHandler : Handler<string>
        {
            public StringHandler(Encoding encoding) : base(encoding) { }

            protected internal override ValueTask<string> ReadValueAsync(NpgsqlStreamReader stream, int length)
            {
                var valueSpan = stream.GetSpan(length);
                if (valueSpan.Length < length)
                    return ReadValueAsyncLong();

                var value = Encoding.GetString(valueSpan);
                return new ValueTask<string>(value);

                ValueTask<string> ReadValueAsyncLong()
                {
                    throw new NotImplementedException();
                }
            }

            protected internal override void WriteValue(NpgsqlStreamWriter stream, string value)
            {
                var encoder = Encoding.GetEncoder();
                var bytesMin = Encoding.GetMaxByteCount(1);
                var charIndex = 0;

                bool completed;
                do
                {
                    encoder.Convert(
                        value.AsSpan(charIndex),
                        stream.GetSpan(bytesMin),
                        charIndex == value.Length,
                        out var charsUsed,
                        out var bytesUsed,
                        out completed);

                    charIndex += charsUsed;
                }
                while (!completed);
            }
        }
    }
}
