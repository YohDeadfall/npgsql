﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Npgsql.Expirements.TypeHandling.Handlers
{
    public sealed class CompositeHandlerFactory<T> : NpgsqlTypeHandlerFactory
    {
        public override NpgsqlTypeHandler CreateHandler(Type runtimeType, PostgresType postgresType, NpgsqlConnection connection)
        {
            var properties = runtimeType.GetProperties();
            var handlers = new CompositeMemberHandler[properties.Length];

            for (var index = properties.Length - 1; index >= 0; index--)
            {
                var property = properties[index];
                var handler = Unsafe.As<CompositeMemberHandler>(connection.TypeMapper
                    .GetHandler(property.PropertyType)
                    .CreateHandler(property.PropertyType, null!, null!));
            }
        }

        private sealed class CompositeHandler : NpgsqlTypeHandler<T>
        {
            private readonly Func<T>? _constructor;
            private readonly CompositeMemberHandler[] _memberHandlers;

            public CompositeHandler()
            {

            }

            protected internal override async ValueTask<T> ReadValueAsync(NpgsqlStreamReader stream, int length)
            {
                var fieldCount = stream.ReadInt32();
                if (fieldCount != _memberHandlers.Length)
                    throw new InvalidOperationException();

                Debug.Assert(_constructor != null);

                var composite = _constructor();
                foreach (var memberHandler in _memberHandlers)
                    await memberHandler.ReadMemberAsync(stream, composite);

                return composite;

                throw new NotImplementedException();
            }

            protected internal override void WriteValue(NpgsqlStreamWriter stream, T value)
            {
                throw new NotImplementedException();
            }
        }

        private interface CompositeMemberHandler
        {
            ValueTask ReadMemberAsync(NpgsqlStreamReader stream, T composite);
            void WriteMemberAsync(NpgsqlStreamWriter stream, T composite);
        }

        private sealed class CompositeMemberHandlerFactory : NpgsqlTypeHandlerFactory
        {
            public override NpgsqlTypeHandler CreateHandler(Type runtimeType, PostgresType postgresType, NpgsqlConnection connection)
            {
                throw new NotImplementedException();
            }
        }

        private sealed class CompositeMemberHandler<TMember> : NpgsqlTypeHandler<TMember>, CompositeMemberHandler
        {
            private delegate TMember GetMember(T composite);
            private delegate void SetMember(T composite, TMember value);

            private readonly GetMember? _get;
            private readonly SetMember? _set;
            private readonly PostgresType _memberType;
            private readonly NpgsqlTypeHandler<TMember> _memberHandler;

            protected internal override ValueTask<TMember> ReadValueAsync(NpgsqlStreamReader stream, int length) =>
                throw new NotSupportedException();

            protected internal override void WriteValue(NpgsqlStreamWriter stream, TMember value) =>
                throw new NotSupportedException();

            public async ValueTask ReadMemberAsync(NpgsqlStreamReader stream, T composite)
            {
                if (_set == null)
                    throw new InvalidOperationException();

                var oid = stream.ReadInt32();
                var value = await _memberHandler.ReadAsync(stream);

                _set(composite, value);
            }

            public void WriteMemberAsync(NpgsqlStreamWriter stream, T composite)
            {
                if (_get == null)
                    throw new InvalidOperationException();

                stream.WriteInt32(_memberType.Oid);
                _memberHandler.WriteValue(stream, _get(composite));
            }
        }
    }
}
