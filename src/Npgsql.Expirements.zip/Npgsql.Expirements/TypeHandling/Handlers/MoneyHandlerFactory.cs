﻿using System;
using System.Threading.Tasks;

namespace Npgsql.Expirements.TypeHandling.Handlers
{
    public sealed class MoneyHandlerFactory : NpgsqlTypeHandlerFactory
    {
        private static readonly Handler s_handler = new Handler(2);

        private const int NativeLength = sizeof(long);

        public override NpgsqlTypeHandler CreateHandler(Type runtimeType, PostgresType postgresType, NpgsqlConnection connection)
        {
            if (runtimeType != typeof(decimal))
                throw runtimeType is null
                    ? new ArgumentNullException(nameof(runtimeType))
                    : new ArgumentException("The runtime type isn't supported.", nameof(runtimeType));

            if (postgresType is null)
                throw new ArgumentNullException(nameof(postgresType));

            if (postgresType.Length != NativeLength)
                throw new ArgumentException("Type length must be equal to 2 bytes.", nameof(postgresType));

            return s_handler;
        }

        private sealed class Handler : NpgsqlTypeHandler<decimal>
        {
            public int Precision { get; }

            public Handler(int precision) : base(NativeLength) => Precision = precision;

            protected internal override ValueTask<decimal> ReadValueAsync(NpgsqlStreamReader stream, int length) =>
                new ValueTask<decimal>(new DecimalRaw(stream.ReadInt64()) { Scale = Precision }.Value);

            protected internal override void WriteValue(NpgsqlStreamWriter stream, decimal value)
            {
                var raw = new DecimalRaw(value);

                var scaleDifference = Precision - raw.Scale;
                if (scaleDifference > 0)
                    DecimalRaw.Multiply(ref raw, DecimalRaw.Powers10[scaleDifference]);
                else
                {
                    value = Math.Round(value, Precision, MidpointRounding.AwayFromZero);
                    raw = new DecimalRaw(value);
                }

                var native = (long)(raw.Mid << 32) | raw.Low;
                if (raw.Negative)
                {
                    if ((ulong)native > 9223372036854775808)
                        throw new OverflowException();

                    native = -native;
                }
                else
                {
                    if ((ulong)native > 9223372036854775807)
                        throw new OverflowException();
                }

                stream.WriteInt64(native);
            }
        }
    }
}
