﻿using System;
using System.Threading.Tasks;

namespace Npgsql.Expirements.TypeHandling
{
    public abstract class NpgsqlTypeHandler<T> : NpgsqlTypeHandler
    {
        internal int Length { get; }

        protected NpgsqlTypeHandler() => Length = 0;

        protected NpgsqlTypeHandler(int length) => Length = length > 0 ? length : throw new ArgumentOutOfRangeException();

        public ValueTask<T> ReadAsync(NpgsqlStreamReader stream) => stream.ReadAsync<T>(this);

        public void Write(NpgsqlStreamWriter stream, T value) => stream.Write(this, value);

        protected internal abstract ValueTask<T> ReadValueAsync(NpgsqlStreamReader stream, int length);

        protected internal abstract void WriteValue(NpgsqlStreamWriter stream, T value);

        internal sealed override async ValueTask<object?> ReadObjectAsync(NpgsqlStreamReader stream) => await ReadAsync(stream);

        internal sealed override void WriteParameter(NpgsqlStreamWriter stream, NpgsqlParameter parameter)
        {
            var value = parameter is NpgsqlParameter<T> typedParameter
                ? typedParameter.Value
                : (T)parameter.Value!;

            Write(stream, value);
        }

        internal override NpgsqlTypeHandler CreateHandler(Type runtimeType, PostgresType postgresType, NpgsqlTypeHandlerFactory factory) =>
            factory.CreateHandler(runtimeType, postgresType, this);
    }
}
